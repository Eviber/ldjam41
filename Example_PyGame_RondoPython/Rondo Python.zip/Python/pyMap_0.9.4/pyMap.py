from pyMain import *

pymap = pyMain()
pymap.run()
