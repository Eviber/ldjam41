# -*- coding: utf-8 -*-
"""
Created on Sun Nov 17 13:54:39 2013

@author: Lexou
"""

import pygame
import spritesheet
import pyganim
from pygame import *
from player import *
from enemies import *

WINDOW_WIDTH = 256
WINDOW_HEIGHT = 224

DISPLAY = (256, 224)
FLAGS = 0
DEPTH = 16
#on definit le variables d'ouverture de fenetre


def main():
# c'est la fonction principale du jeu
    pygame.init()
    # initialiser la librairie pygame
    screen = display.set_mode(DISPLAY, FLAGS, DEPTH)
    # screen est la fenetre q'ouvre le programme pour y afficher le jeu
    display.set_caption("Projet ISN")
    # faire que la barre titre de la fenetre affiche "Projet ISN"
    timer = time.Clock()
    # timer est assigné a une fonction de pygame qui permet de lancer les frames du jeu
    
    up=releaseUp=down=releaseDown=left=releaseLeft=right=releaseRight=Abutton=releaseAbutton=Bbutton=releaseBbutton=Lbutton=releaseLbutton=Rbutton=releaseRbutton = False
    # on assigne faux a toutes les valeurs des touches enfoncées et relachées (haut, bas gauche, droite, A, B, L et R)
    
    bg = Surface((16,16))
    # bg (background) designe le decor
    bg.convert()
    # convertir le format d'image en format utilisable par le programme
    bg.fill(Color("#888888"))
    # peindre the decor en noir
    
    entities = pygame.sprite.Group()
    # entities est un groupe contenant tous les sprites du jeu
    enemies = pygame.sprite.Group()
    
    player = Player(16, 128)
    # creer l'instance "player" de la classe "Player", les parametres definissent son lieu d'apparition (x,y)
#    medusahead = MedusaHead(280,  270, False)
#    bonepillar = BonePillar(208, 160, False)


    platforms = []
    # creer la liste platforms
    
    x = y = 0
    # creer x et y, d'abord a 0
    level = [
#    "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
#    "PPPP                T             P",
#    "PPPPT               T             P",
#    "PPPPPPPPP        PPPP             P",
#    "PPPP     PP     P   P             P",
#    "PPPP       PP       P             P",
#    "PPPP         P      P             P",
#    "PPPP          P    PP    PPPPPPPPPP",
#    "PPPPPP            P P             P",
#    "PPPP             P  P             P",
#    "PPPP            P   PPPPPPPPPP    P",
#    "PPPPT       PPPP    P             P",
#    "PPPP       P        PPP         PPP",
#    "PPPPPPPP            PPPP       PPPP",
#    "P       P          PPPPPP     PPPPP",
#    "P        P         PP             P",
#    "P         PP       PP             P",
#    "P              PPPPPP             P",
#    "P              PPPPPP             P",
#    "P            PPPPPPPP            EP",
#    "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P",
    "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
    "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
    "P                              P",
    "P                              P",
    "P                              P",
    "P                              P"]
    
#    # construire le niveau avec la liste level
    for row in level:
        for col in row:
            if col == "P":
                p = Platform(x, y)
                platforms.append(p)
                entities.add(p)
            if col == "T":
                t = Target(x, y)
                entities.add(t)
            if col == "E":
                e = ExitBlock(x, y)
                platforms.append(e)
                entities.add(e)
            x += 16
        y += 16
        x = 0
    # boucle qui va remplir la liste platforms d'objets plateformes
    platformGroup = sprite.Group()
    for p in platforms:
        platformGroup.add(p)
            
    levelWidth  = 512
    levelHeight = 224

    camera = Camera(player_camera, levelWidth, levelHeight)


    entities.add(player)
    # ajouter l'instance player et fouet a la liste d'entités
    entities.add(player.attack)
    # ajouter l'instance player et fouet a la liste d'entités
#    entities.add(medusahead)
#    enemies.add(medusahead)
#    entities.add(bonepillar)
#    enemies.add(bonepillar)
    
    myfont = pygame.font.SysFont("monospace", 12)
    
    while 1:
    # la boucle principale qui permet de faire tourner le jeu
        timer.tick(30)
        # regler le nombre d'images/seconde a 30
        
        prevUp = up
        prevDown = down
        prevLeft = left
        prevRight = right
        prevAbutton = Abutton
        prevBbutton = Bbutton
        prevLbutton = Lbutton
        prevRbutton = Rbutton
        # ces variables correspondent aux touches enfoncees a la frame precedente
        
        for e in pygame.event.get():
            if e.type == QUIT: raise SystemExit, "QUIT"
            # si on appuye sur la croix, quitter le programme
            if e.type == KEYDOWN and e.key == K_ESCAPE: 
                raise SystemExit, "ESCAPE"
            # si on appuye sur echap, quitter le programme
            
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_DOWN:
                down = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True
            if e.type == KEYDOWN and e.key == K_SPACE:
                Abutton = True
            if e.type == KEYDOWN and e.key == K_LALT:
                Bbutton = True
            if e.type == KEYDOWN and e.key == K_LCTRL:
                Lbutton = True
            if e.type == KEYDOWN and e.key == K_RCTRL:
                Lbutton = True
            # assigner up, down left et right aux touches fleches enfoncees, A et B aux touches espace et alt, et L et R aux touches ctrl d/g

            if e.type == KEYUP and e.key == K_UP:
                up = False
                if prevUp:  releaseUp = True
                if not prevUp:  releaseUp = False
            if e.type == KEYUP and e.key == K_DOWN:
                down = False
                if prevDown:  releaseDown = True
                if not prevDown:  releaseDown = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False
                if prevLeft:  releaseLeft = True
                if not prevLeft:  releaseLeft = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
                if prevRight:  releaseRight = True
                if not prevRight:  releaseRight = False
            if e.type == KEYUP and e.key == K_SPACE:
                Abutton = False
                if prevAbutton:  releaseAbutton = True
                if not prevAbutton:  releaseAbutton = False
            if e.type == KEYUP and e.key == K_LALT:
                Bbutton = False
                if prevBbutton:  releaseBbutton = True
                if not prevBbutton:  releaseBbutton = False
            if e.type == KEYUP and e.key == K_LCTRL:
                Lbutton = False
                if prevLbutton:  releaseLbutton = True
                if not prevLbutton:  releaseLbutton = False
            if e.type == KEYUP and e.key == K_RCTRL:
                Rbutton = False
                if prevRbutton:  releaseRbutton = True
                if not prevRbutton:  releaseRbutton = False
            # assigner releaseUp etc aux touches fleches qui viennent d'etre relachées
        
        for y in range(20):
            for x in range(35):
                screen.blit(bg, (x * 16, y * 16))
        # afficher a l'ecran le decor
                
        camera.update(player)

        player.update(up, releaseUp,
                      down, releaseDown,
                      left, releaseLeft,
                      right, releaseRight,
                      Abutton, releaseAbutton,
                      Bbutton, releaseBbutton,
                      Lbutton, releaseLbutton,
                      Rbutton, releaseRbutton,
                      platforms, enemies)
        # mettre a jour l'objet player

#        for n in enemies:
#            n.update()

        for e in entities:
            screen.blit(e.image, camera.apply(e))
            # afficher tous les sprites
            
        xcoordblit = myfont.render("x = "+str(player.xcoord), 1, (0,0,0))
        ycoordblit = myfont.render("y = "+str(player.ycoord), 1, (0,0,0))
    
        xvelblit = myfont.render("xvel = "+str(player.xvel), 1, (0,0,0))
        yvelblit = myfont.render("yvel = "+str(player.yvel), 1, (0,0,0))
        
        onGroundblit = myfont.render("whipped = "+str(player.whipped), 1, (0,0,0))




        screen.blit(xcoordblit, (6, 6))
        screen.blit(ycoordblit, (6, 22))
        screen.blit(xvelblit, (6, 38))
        screen.blit(yvelblit, (6, 54))
        screen.blit(onGroundblit, (6, 70))
            
        pygame.display.update()
        # appliquer les affichages dictés à la fenetre




class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)
        
def player_camera(level, target_rect):
    xcoord = target_rect[0]
    ycoord = target_rect[1]
    xlength = level[2]
    ylength = level[3]
    xcoord = -xcoord+(WINDOW_WIDTH/2)
    ycoord = -ycoord+(WINDOW_HEIGHT/2)
    
    xcoord = min(0, xcoord)                           # stop scrolling at the left edge
    xcoord = max(-(level.width-WINDOW_WIDTH), xcoord)   # stop scrolling at the right edge
    ycoord = max(-(level.height-WINDOW_HEIGHT), ycoord) # stop scrolling at the bottom
    ycoord = min(0, ycoord)                           # stop scrolling at the top

    return Rect(xcoord, ycoord, xlength, ylength)
    
    
    
    
class Entity(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
    # classe qui permet de facilement definir les fonctions d'initialisation automatique qu'auront toutes les classes par heritage


class Platform(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.image = Surface((16, 16))
        self.image.convert()
        self.image.fill(Color("#DDDDDD"))
        self.rect = Rect(x, y, 16, 16)
    # carres de taille 16x16, de couleur gris clair, non-penetrables
    
    def update(self):
        pass
    # on donne aux plateformes une fonction update pour la forme, mais elle est inutile actuellement

class ExitBlock(Platform):
    def __init__(self, x, y):
        Platform.__init__(self, x, y)
        self.image.fill(Color("#0033FF"))
    # carre bleu qui sert de sortie
        
class Target(Platform):
    def __init__(self, x, y):
        Platform.__init__(self, x, y)
        self.image.fill(Color("#DD3311"))
    # cible (carre rouge) utilisée pour tester les attaques
        


if(__name__ == "__main__"):
    main()