# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 17:35:12 2013

@author: Lexou
"""

import pygame
import spritesheet
import pyganim
from pyganim import *
from pygame import *
from platformer import *

class Entity(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
    # classe qui permet de facilement definir les fonctions d'initialisation automatique qu'auront toutes les classes par heritage

class Enemy(Entity):
    def __init__(self, x, y, facingRight):
        Entity.__init__(self)
        
        self.xcoord = x
        self.ycoord = y
        # les coordonnées x et y de l'ennemi
        
        self.xvel = 0
        self.yvel = 0
        # velocité x et y de l'ennemi
        
        self.enemysheet = spritesheet.spritesheet("Enemy.png")
        # Le spritesheet contenant tous les sprites ennemis
        
        self.facingRight = facingRight
    
    

class BonePillar(Enemy):
# les squelettes en pile qui crachent du feu
    def __init__(self, x, y, facingRight):
        Enemy.__init__(self, x, y, facingRight)
        
        self.attack = self.Fireball(x, y, facingRight)
        
        self.idling = True
        self.attacking = False
        self.dying = False
        
        self.idlecount = 0
        
        self.image = self.enemysheet.image_at((6,470,24,16), colorkey=(185,209,217))
        
        self.rect = Rect(x, y, 24, 16)

    def update(self):
        
        if self.idling:
            self.idle()
            
        if self.idlecount > 60 or self.attacking:
            self.attack()
        
        if self.dying:
            self.die()
        
        self.rect.centerx += self.xvel
        # incrementer la postion du rectangle d'occupation ennemi en direction x
        self.xcoord = self.rect.topleft[0]
        # mettre à jour la valuer de xcoord
        
        self.rect.centery += self.yvel
        # incrementer la postion du rectangle d'occupation ennemi en direction y
        self.ycoord = self.rect.topleft[1]
        # mettre a jour la valeur de ycoord
        
        if self.facingRight:
            self.image = transform.flip(self.image, True, False)
        # si l'ennemi regarde vers la gauche, retourner horizontalement le sprite
            
    def idle(self):
        
        self.xvel = 0
        self.image = self.enemysheet.image_at((6,470,24,16), colorkey=(185,209,217))
        self.idlecount += 1
        
    def attack(self):
        self.attacking = True
        self.idlecount = 0
        self.image = self.enemysheet.image_at((32,470,24,16), colorkey=(185,209,217))
        if not sprite.collide_rect(self, self.fireball):
            self.attacking = False
            
    def fall(self):
    # fonction pour appliquer la gravité au joueur
        self.yvel += 0.5
        # acceleration due à la gravité si l'on est en l'air
        if self.yvel > 25: self.yvel = 25
        # vitesse de chute max
        
        
    class Fireball(Enemy):
        def __init__(self, x, y, facingRight):
            Enemy.__init__(self, x, y, facingRight)
            
            self.facingRight = facingRight
            
            self.image = self.enemysheet.image_at((62,470,8,8), colorkey=(185,209,217))
            
            self.rect = Rect(x, y, 8, 8)
            
        def update(self):
            
            if self.facingRight:
                self.xvel = 3
            if not self.facingRight:
                self.xvel = -3
                
            self.rect.centerx += self.xvel
            # incrementer la postion du rectangle d'occupation ennemi en direction x
            self.xcoord = self.rect.topleft[0]
            # mettre à jour la valuer de xcoord
            
            self.rect.centery += self.yvel
            # incrementer la postion du rectangle d'occupation ennemi en direction y
            self.ycoord = self.rect.topleft[1]
            # mettre a jour la valeur de ycoord
            if self.facingRight:
                self.image = transform.flip(self.image, True, False)


class MedusaHead(Enemy):
# les tetes de gorgonne flottantes
    def __init__(self, x, y, facingRight):
        Enemy.__init__(self, x, y, facingRight)
        
        self.moving = True
        self.dying = False
        
        self.goingUp = True
        
        self.image = self.enemysheet.image_at((6,538,16,16), colorkey=(185,209,217))
        
        self.rect = Rect(x, y, 16, 16)

    def update(self):
        
        if self.moving:
            self.move()
        
        if self.dying:
            self.die()
        
        self.rect.centerx += self.xvel
        # incrementer la postion du rectangle d'occupation ennemi en direction x
        self.xcoord = self.rect.topleft[0]
        # mettre à jour la valuer de xcoord
        
        self.rect.centery += self.yvel
        # incrementer la postion du rectangle d'occupation ennemi en direction y
        self.ycoord = self.rect.topleft[1]
        # mettre a jour la valeur de ycoord
        
        if self.yvel < 0:
            self.image = self.enemysheet.image_at((6,538,16,16), colorkey=(185,209,217))
        if self.yvel > 0:
            self.image = self.enemysheet.image_at((24,538,16,16), colorkey=(185,209,217))
        if self.facingRight:
            self.image = transform.flip(self.image, True, False)
        # si l'ennemi regarde vers la gauche, retourner horizontalement le sprite
        
    def move(self):
        self.moving = True
        if self.facingRight:
            self.xvel = 2
        if not self.facingRight:
            self.xvel = -2
        if self.yvel > 3:
            self.goingUp = True
        if self.yvel < -2:
            self.goingUp = False
        if self.goingUp:
            self.yvel += -0.2
        if not self.goingUp:
            self.yvel += 0.2
        
    def die():
        pass