# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 14:25:47 2013

@author: Lexou

Ce fichier contient la classe Player qui est le joueur, ainsi que la sous-classe Attack qui gere les hitbox des attaques
"""

# Ce fichier contient toutes les classes mobiles du jeu : joueur, ennemis, boss etc

import pygame
import spritesheet
import pyganim
from pyganim import *
from pygame import *
from platformer import *



class Player(Entity):
# classe du joueur
    def __init__(self, x, y):
        Entity.__init__(self)
        
        self.richtersheet = spritesheet.spritesheet("Richter.png")
        # la spritesheet du joueur : toutes les frames d'animation de celui-ci
        
        self.attack = self.Attack(x, y, self.richtersheet)
        # creer l'instance "attack" de la classe "Attack", les parametres definissent son lieu d'apparition (x,y)
        
        self.xcoord = x
        self.ycoord = y
        # coordonnees du sprite player
        self.xvel = 0
        self.yvel = 0
        # velocité x et y du joueur
        
        self.facingRight = True
        # si le joueur regarde a droite ou pas (afin de retourner les animations)
        self.onGround = True
        # si le joueur touche le sol
        self.invulnerable = False
        # si le joueur peut prendre des degats
        
        self.takingDamage = False
        # si le joueur est en train d'etre ejecte par un ennemi
        self.idling = True
        # si le joueur ne fait rien
        self.walking = False
        # si le joueur est en train de marcher au sol
        self.taunting = False
        # si le joueur est en train de se la peter (appuyer sur haut)
        self.crouching = False
        # si le joueur est accroupi
        self.jumping = False
        # si le joueur est en train de sauter
        self.backflipping = False
        # si le joueur est en train de faire un salto arriere
        self.whipping = False
        # si le joueur est en train d'attaquer au fouet
        self.jumpwhipping = False
        # si le joueur est en train d'attaquer au fouet en l'air
        self.sliding = False
        # si le joueur est en train de glisser sur le sol
        self.slidekicking = False
        # si le joueur effectue l'attaque du coup de pied glissade aerien
        
        self.jumped = False
        # si le joueur a sauté precedemment
        self.backflipped = False
        # si le joueur a deja effectué un salto arriere
        self.whipped = False
        # si le joueur a fouetté precedemment
        self.slided = False
        # si le joueur a glissé precedemment
        self.slidekicked = False
        # si le joueur a effectue l'attaque du coup de pied glissade aerien precedemment
        

        self.image = self.richtersheet.image_at((2,2,16,32), colorkey=(185,209,217))
        # image est l'image representant le joueur a tout moment, d'abord reglé sur la pose debout fixe
        self.image.convert()
        # convertir l'image joueur
        self.elapsed = None
        # à ou en est l'animation actuelle du joueur
        
        self.animWalk = pyganim.PygAnimation([
            (self.richtersheet.image_at((2,138,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((20,138,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((38,138,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((56,138,16,32), colorkey=(185,209,217)), 0.2)])
        # animation de marche du joueur
        self.animBackflip = pyganim.PygAnimation([
            (self.richtersheet.image_at((2,580,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((20,580,24,32), colorkey=(185,209,217)), 0.07),
            (self.richtersheet.image_at((46,580,24,32), colorkey=(185,209,217)), 0.07),
            (self.richtersheet.image_at((72,580,24,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((98,580,32,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((132,580,24,32), colorkey=(185,209,217)), 0.1)], False)
        self.animBackflip.loop = False
        # animation de salto arriere
        self.animWhipGround = pyganim.PygAnimation([
            (self.richtersheet.image_at((18,206,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((60,206,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((78,206,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((136,206,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((202,206,16,32), colorkey=(185,209,217)), 0.05)], False)
        self.animWhipGround.loop = False
        # animation d'attaque fouet au sol du joueur
        self.animWhipCrouch = pyganim.PygAnimation([
            (self.richtersheet.image_at((18,308,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((60,308,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((78,308,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((136,308,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((202,308,16,32), colorkey=(185,209,217)), 0.05)], False)
        self.animWhipCrouch.loop = False
        # animation d'attaque fouet du joueur accroupi
        self.animWhipJump = pyganim.PygAnimation([
            (self.richtersheet.image_at((18,410,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((60,410,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((78,410,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((136,410,16,32), colorkey=(185,209,217)), 0.2),
            (self.richtersheet.image_at((202,410,16,32), colorkey=(185,209,217)), 0.05)], False)
        self.animWhipJump.loop = False
        # animation d'attaque fouet du joueur en l'air
        self.animSlide = pyganim.PygAnimation([
            (self.richtersheet.image_at((2,512,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((28,512,16,32), colorkey=(185,209,217)), 0.05),
            (self.richtersheet.image_at((62,512,16,32), colorkey=(185,209,217)), 0.3),
            (self.richtersheet.image_at((96,512,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((130,512,16,32), colorkey=(185,209,217)), 0.1)], False)
        self.animSlide.loop = False
        # animation de glissage au sol du joueur
        self.animSlidekick = pyganim.PygAnimation([
            (self.richtersheet.image_at((2,546,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((36,546,16,32), colorkey=(185,209,217)), 0.4),
            (self.richtersheet.image_at((70,546,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((104,546,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((138,546,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((164,546,16,32), colorkey=(185,209,217)), 0.1),
            (self.richtersheet.image_at((182,546,16,32), colorkey=(185,209,217)), 0.1)], False)
        self.animSlidekick.loop = False
        # animation de coup de pied aerien du joueur
        
        self.rect = Rect(x, y, 16, 32)
        # la rectangle d'occupation du joueur, qui va detecter les collisions avec les murs, etc
        self.hitbox = Rect(x+2, y+2, 12, 30)
        # la hitbox du joueur qui va detecter les collisions avec les ennemis



    def update(self, up, releaseUp,
               down, releaseDown,
               left, releaseLeft,
               right, releaseRight,
               Abutton, releaseAbutton,
               Bbutton, releaseBbutton,
               Lbutton, releaseLbutton,
               Rbutton, releaseRbutton,
               platforms, enemies):
    # fonction de mise a jour du joueur, joue le lien avec toutes les autres fonctions
        self.elapsed = None
        
        if not self.onGround:
            self.fall()
        # mettre en oeuvre la gravité si le joueur n'est pas au sol
            
        if Abutton and self.sliding and self.animSlide.elapsed > 0.2 and not self.slidekicked:
            self.yvel = -5
            self.slidekick()
        # si l'on appuye sur A pendant une glissade, le faire faire un slidekick
        

        if not (self.backflipping or self.whipping or self.sliding or self.slidekicking or self.takingDamage):
        # si le joueur n'est pas en train d'effectuer des actions prioritaires
        
            if up or down or left or right or Abutton or Bbutton:
                self.idling = False
                # si un bouton est enfoncé, le joueur n'est plus fixe
        
            if (left or right):
                self.walk(left, right)
            # si l'on appuye sur gauche ou droite, le faire marcher dans ladite direction
            if (releaseLeft or releaseRight):
                self.walking = False

            if Abutton and not self.crouching:
                self.jump()
            # si l'on appuye sur A lorsque le joueur n'est pas accroupi, le faire sauter
                
            if Bbutton and not self.whipped:
                self.whipattack()
            # si l'on appuye sur B, le faire attaquer au fouet
            
            if Lbutton and not self.onGround and not self.backflipped:
                self.backflip()
            # si l'on appuye sur L en l'air, faire un salto arriere

            if self.onGround:
            # si le joueur est au sol
                if not(up or down or left or right or Abutton or Bbutton):
                    self.idle()
                # si aucune touche n'est enfoncée, le mettre en etat fixe

                if up:
                    self.taunt()
                # si l'on appuye sur haut, lui faire prendre la pose

                if down:
                    self.crouch()
                # si l'on appuye sur bas, le faire s'accroupir

                if Abutton and self.crouching and not self.slided:
                    self.slide()
                # si l'on appuye sur A lorsque le joueur est accroupi, le faire glisser
                

        if not Abutton and self.onGround:
            self.jumped = False
        if not Lbutton and self.onGround:
            self.backflipped = False
        if not Bbutton and not self.whipping:
            self.whipped = False
        if not Abutton and not self.sliding:
            self.slided = False
        if self.onGround and not self.slidekicking:
            self.slidekicked = False
        # ces variables permettent en fait de verifier que le joueur a bien relaché la touche
        # afin qu'il ne puisse pas garder appuyé pour repeter l'action a l'infini

        if self.whipping:
            self.whipattack()
        if self.sliding:
            self.slide()
        if self.slidekicking:
            self.slidekick()
        if self.backflipping:
            self.backflip()
        if self.takingDamage:
            self.takedamage()
            
            

        
        
        if (self.takingDamage or
            self.idling or
            self.walking or
            self.taunting or
            self.jumping or
            self.backflipping or
            self.whipping or
            self.jumpwhipping):
            self.hitbox = Rect(self.xcoord+2, self.ycoord+2, 12, 30)
            
        if (self.crouching):
            self.hitbox = Rect(self.xcoord+2, self.ycoord+16, 12, 16)
            
        if (self.sliding or
            self.slidekicking):
            self.hitbox = Rect(self.xcoord+2, self.ycoord+18, 12, 14)
            
            
        self.rect.x += self.xvel
        # incrementer la postion du rectangle d'occupation joueur en direction x
        self.xcoord = self.rect.x
        # mettre à jour la valuer de xcoord
        self.collidewall(self.xvel, 0, platforms)
        
        self.rect.y += self.yvel
        # incrementer la postion du rectangle d'occupation joueur en direction y
        self.ycoord = self.rect.y
        # mettre a jour la valeur de ycoord
        self.collidewall(0, self.yvel, platforms)
        
        
        # verifier les collisions avec les murs
#        self.collideenemy(enemies)
        # verifier les collisions avec les ennemis
        
        if isinstance(self.image, PygAnimation):
            self.elapsed = self.image.elapsed
            self.image = self.image.getCurrentFrame()
        # si l'image joueur est un objet animation, le transformer en objet surface, et noter ou en est son animation dans elapsed
        if not self.facingRight:
            self.image = transform.flip(self.image, True, False)
        # si le joueur regarde vers la gauche, retourner horizontalement le sprite
            
            
        self.attack.update(self.onGround,
                           self.crouching,
                           self.whipping,
                           self.sliding,
                           self.slidekicking,
                           self.facingRight,
                           self.elapsed,
                           self.xcoord, self.ycoord,
                           self.richtersheet,
                           enemies)
        # mettre a jour l'objet attack
    
    def collidewall(self, xvel, yvel, platforms):
    #"""
    #fonction pour verifier les collisions du joueur aux murs
    #"""
        collideUnder = 0
        # la variable qui verifie s'il y a bien un solide sous les pieds du joueur
        for p in platforms:
        # boucle: pour tout p dans la liste des plateformes du jeu
            if sprite.collide_rect(self, p):
#            if self.hitbox.colliderect(p.rect):
            # si il y a collision entre le joueur et le dit p
                if xvel > 0:
                    self.rect.right = p.rect.left
#                    self.xvel = 0
                # si la velocite horizontale va vers la droite, replacer le rectangle joueur au bord gauche du rectangle plateforme
                if xvel < 0:
                    self.rect.left = p.rect.right
#                    self.xvel = 0
                # si la velocite horizontale va vers la gauche, replacer le rectangle joueur au bord droit du rectangle plateforme
                if yvel > 0:
                # si la velocite verticale va vers le bas
                    self.rect.bottom = p.rect.top
                    # replacer le rectangle joueur au bord haut du rectangle plateforme
                    self.onGround = True
                    # le joueur est bien desormais au sol
                    self.jumping = False
                    self.yvel = 0
                    # il n'a plus de velocité verticale
                if yvel < 0:
                # si la velocite verticale va vers le haut
                    self.rect.top = p.rect.bottom
                    # replacer le rectangle joueur au bord bas du rectangle plateforme
                    self.yvel = 0
                    # il descend desormais
            if p.rect.collidepoint(self.rect.left, self.rect.bottom) or p.rect.collidepoint(self.rect.right, self.rect.bottom):
            # si en dessous du bord droit ou du bord gauche du rectangle joueur il y a le dit p
                collideUnder += 1
                # ajouter 1 a la variable des collsions sous le joueur
            if self.slidekicking and self.animSlidekick.elapsed <= 0.7:
                if  self.facingRight and p.rect.collidepoint(self.rect.right+14, self.rect.centery):
                    self.slidekicking = False
                    self.backflip()
                if not self.facingRight and p.rect.collidepoint(self.rect.left-14, self.rect.centery):
                    self.slidekicking = False
                    self.backflip()
        if collideUnder==0:
        # si a l'issue de la boucle il n'y a pas eu de collision sous le joueur
            self.onGround = False
            # le joueur n'est donc pas au sol
            
    def collideenemy(self, enemies):
        for n in enemies:
            if self.hitbox.colliderect(n.rect):
                self.takingDamage = True

    def idle(self):
    # fonction pour que le joueur reste debout, fixe
        self.image = self.richtersheet.image_at((2,2,16,32), colorkey=(185,209,217))
        # l'image est mise sur la pose fixe du personnage
        if self.taunting:
            self.image = self.richtersheet.image_at((2,36,16,32), colorkey=(185,209,217))
        # ceci sert a faire la frame de transition
        if self.crouching:
            self.image = self.richtersheet.image_at((2,70,16,32), colorkey=(185,209,217))
        # ceci sert a faire la frame de transition
        self.xvel = 0
        # le joueur est fixe
        self.onGround = True
        # il est bien au sol
        self.idling = True
        # il est en train de ne rien faire
        self.taunting = False
        # il n'accede pas au attaques speciales
        self.crouching = False
        # il n'est plus accroupi

    def taunt(self):
    # fonction qui met le joueur en etat d'attaques altérées (objet/armes)
        if not self.taunting:
            self.image = self.richtersheet.image_at((2,36,16,32), colorkey=(185,209,217))
        # ceci sert a faire la frame de transition
        self.crouching = False
        # il n'est donc pas accroupi
        self.xvel = 0
        # il ne peut bouger
        if self.taunting:
            self.image = self.richtersheet.image_at((20,36,16,32), colorkey=(185,209,217))
            # l'image joueur est mise sur la pose du taunt
        self.taunting = True
        # il est bien en train de se la peter
                
    def crouch(self):
    # fonction pour faire s'accroupir le joueur
        if not self.crouching:
            self.image = self.richtersheet.image_at((2,70,16,32), colorkey=(185,209,217))
        self.taunting = False
        # le joueur n'est donc pas en train de se la peter
        self.xvel = 0
        # il ne peut bouger
        if self.crouching:
            self.image = self.richtersheet.image_at((20,70,16,32), colorkey=(185,209,217))
            # l'image joueur est mise sur la pose accroupie
        self.crouching = True
        # le joueur est bien accroupi
                
    def walk(self, left, right):
    # fonction pour faire marcher le joueur
        self.walking = True
        # le joueur est en train de marcher
        if right:
        # si on marche a droite
            self.xvel = 2
            # la velocité horizontale est mise a 2
            if not self.facingRight: self.facingRight = True
            # si le joueur ne regardait pas vers la droite avant, maintenant oui
            if self.onGround:
            # si le joueur est au sol
                self.image = self.animWalk
                # l'image joueur est mise sur l'animation de marche du joueur
                self.animWalk.play()
                # lancer l'animation
                self.crouching = False
                # le joueur n'est donc pas accroupi
                self.taunting = False
                # le joueur ne se la pete pas
        if left:
        # si on marche a gauche
            self.xvel = -2
            # la velocite horizontale du joueur est mise a -2
            if self.facingRight: self.facingRight = False
            # si le joueur ne regardait pas a gauche avant, maintenant oui
            if self.onGround:
            # si le joueur est au sol
                self.image = self.animWalk
                # l'image joueur est mise sur l'animation de marche du joueur
                self.animWalk.play()
                # lancer l'animation
                self.crouching = False
                # le joueur n'est donc pas accroupi
                self.taunting = False
                # le joueur ne se la pete pas
        if not self.walking:
            self.animWalk.stop()
                
    def jump(self):
    # fonction pour faire sauter le joueur
        if self.onGround and not self.jumped:
        # si le joueur est au sol et qu'il n'a pas sauté précédemment
            self.crouching = False
            self.taunting = False
            self.yvel = -5
            # la velocité verticale est mise a -4
            self.jumping = True
            # le joueur est en train de sauter
            self.jumped = True
            # le joueur a donc sauté précédemment
            self.onGround = False
            # le joueur n'est donc plus au sol
        if self.jumped and self.yvel < 0:
        # si le joueur a sauté précédemment et que sa velocite verticale est vers le haut
            self.yvel += -0.2
            # la velocité verticale est diminuée de -0.2 (ce if sert a faire sauter plus haut le joueur si A est enfoncé plus longtemps)
                
    def fall(self):
    # fonction pour appliquer la gravité au joueur
        self.yvel += 0.5
        # acceleration due à la gravité si l'on est en l'air
        if self.yvel > 25: self.yvel = 25
        # vitesse de chute max
        if self.yvel < 0:
        # si la velocite verticale est inferieure ou egale a zero
            if self.xvel == 0:
            # si le joueur est simplement vertical
                self.image = self.richtersheet.image_at((2,104,16,32), colorkey=(185,209,217))
                # l'image joueur est mise sur la pose saut vertical
            else:
            # sinon s'il se deplace horizontalement
                self.image = self.richtersheet.image_at((20,104,16,32), colorkey=(185,209,217))
                # l'image joueur est mise sur la pose du saut en avant
        if 2 >= self.yvel >= 0:
        # si la velocité verticale est descendante
            self.image = self.richtersheet.image_at((38,104,16,32), colorkey=(185,209,217))
            # l'image joueur est mise sur la pose en suspens
        if self.yvel > 2:
            self.image = self.richtersheet.image_at((56,104,16,32), colorkey=(185,209,217))
            # l'image joueur est mise sur la pose descendante
            
    def backflip(self):
    # fonction pour faire un salto arriere
        self.backflipped = True
        if not self.backflipping:
            self.yvel = -3
        self.backflipping = True
        self.image = self.animBackflip
        self.onGround = False
        if self.facingRight:
            self.xvel = -2
        if not self.facingRight:
            self.xvel = 2
        if self.animBackflip.isFinished():
            self.backflipping = False
            self.animBackflip.stop()
            self.image = self.richtersheet.image_at((38,104,16,32), colorkey=(185,209,217))
        if self.backflipping:
            self.animBackflip.play()
    
            
    def whipattack(self):
    # fonction pour faire attaquer le joueur
        self.whipping = True
        # le joueur est bien en train de fouetter
        self.whipped = True
        # le joueur a donc fouetté précédemment
        if not self.onGround:
        # s'il est dans les airs
            self.jumpwhipping = True
            self.image = self.animWhipJump
            # l'image joueur devient l'animation de fouet en l'air
            if self.animWhipJump.isFinished():
            # si cette animation est arrivée a terme
                self.whipping = False
                # le joueur n'est plus en train de fouetter
                self.animWhipJump.stop()
                # arreter l'animation
                self.image = self.richtersheet.image_at((202,410,16,32), colorkey=(185,209,217))
                self.jumpwhipping = False
            if self.whipping:
            # s'il est bien en train de fouetter
                self.animWhipJump.play()
                # jouer l'animation
        if self.onGround and not self.crouching:
        # si le joueur est au sol
            self.xvel = 0
            # il s'arrete de bouger horizontalement
            self.image = self.animWhipGround
            if self.jumpwhipping:
            # si le joueur etait en l'air juste avant
                self.animWhipGround.elapsed = self.animWhipJump.elapsed
                self.animWhipGround.play()
                self.animWhipJump.stop()
                self.jumpwhipping = False
            # s'il atterrit d'un saut, finir avec l'animation au sol
            if self.animWhipGround.isFinished():
                self.whipping = False
                self.animWhipGround.stop()
                self.image = self.richtersheet.image_at((202,206,16,32), colorkey=(185,209,217))
            if self.whipping:
                self.animWhipGround.play()
        if self.crouching:
            self.image = self.animWhipCrouch
            if self.animWhipCrouch.isFinished():
                self.whipping = False
                self.animWhipCrouch.stop()
                self.image = self.richtersheet.image_at((202,308,16,32), colorkey=(185,209,217))
            if self.whipping:
                self.animWhipCrouch.play()

                    
    def slide(self):
        self.sliding = True
        self.slided = True
        self.crouching = True
        self.image = self.animSlide
        if self.facingRight:
            self.xvel = 4
            if self.animSlide.elapsed > 0.4:
                self.xvel = 2
        if not self.facingRight:
            self.xvel = -4
            if self.animSlide.elapsed > 0.4:
                self.xvel = -2
        if self.animSlide.isFinished():
            self.sliding = False
            self.animSlide.stop()
        if self.sliding:
            self.animSlide.play()
            
    def slidekick(self):
        self.sliding = False
        self.slidekicking = True
        self.slidekicked = True
        self.crouching = False
        self.onGround = False
        self.image = self.animSlidekick
        if self.animSlidekick.elapsed <= 1:
            self.xvel = 3
        if self.animSlidekick.elapsed <= 0.8:
            self.xvel = 5
        if self.animSlidekick.elapsed <= 0.5:
            self.xvel = 6
        if not self.facingRight and self.xvel > 0:
            self.xvel = self.xvel*(-1)
        if self.animSlidekick.isFinished():
            self.slidekicking = False
            self.animSlidekick.stop()
            if self.facingRight: self.facingRight = False
            if not self.facingRight: self.facingRight = True
            self.slidekicked = False
        if self.slidekicking:
            self.animSlidekick.play()
    
    def takedamage(self):
        if not self.takingDamage:
            self.yvel = -2
            self.onGround = False
        if self.facingRight:
            self.xvel = -2
        if not self.facingRight:
            self.xvel = 2
        self.takingDamage = True
        self.invulnerable = True
        if self.onGround:
            self.takingDamage = False
        if self.yvel > 0:
            self.image = self.richtersheet.image_at((2,614,16,32), colorkey=(185,209,217))
        if self.yvel <= 0:
            self.image = self.richtersheet.image_at((20,614,24,24), colorkey=(185,209,217))
        
    

    class Attack(Entity):
    # sous-classe qui gere les animations et collisions pour le fouet et les attaques
        def __init__(self, x, y, richtersheet):
            Entity.__init__(self)
            
            self.xcoord = x
            self.ycoord = y
            # coordonnees du sprite attack
            
            self.animWhipAttack = pyganim.PygAnimation([
                (richtersheet.image_at((2,206,16,24), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((36,206,24,16), colorkey=(185,209,217)), 0.05),
                (richtersheet.image_at((94,206,40,16), colorkey=(185,209,217)), 0.05),
                (richtersheet.image_at((152,206,48,16), colorkey=(185,209,217)), 0.2),
                (richtersheet.image_at((218,206,16,16), colorkey=(185,209,217)), 0.05),
                (richtersheet.image_at((2,70,8,8), colorkey=(185,209,217)), 0.05)], False)
            self.animWhipAttack.loop = False
            # animation du fouet lorsqu'il attaque
            self.animSlide = pyganim.PygAnimation([
                (richtersheet.image_at((18,512,8,32), colorkey=(185,209,217)), 0.05),
                (richtersheet.image_at((44,528,16,16), colorkey=(185,209,217)), 0.05),
                (richtersheet.image_at((78,528,16,16), colorkey=(185,209,217)), 0.3),
                (richtersheet.image_at((112,528,16,16), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((2,70,8,8), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((2,70,8,8), colorkey=(185,209,217)), 0.05)], False)
            self.animSlide.loop = False
            # animation des pieds lorsqu'il glisse
            self.animSlidekick = pyganim.PygAnimation([
                (richtersheet.image_at((18,562,16,16), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((52,562,16,16), colorkey=(185,209,217)), 0.4),
                (richtersheet.image_at((86,562,16,16), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((120,562,16,16), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((154,554,16,24), colorkey=(185,209,217)), 0.1),
                (richtersheet.image_at((2,70,8,8), colorkey=(185,209,217)), 0.05)], False)
            self.animSlidekick.loop = False
            # animation des pieds lors d'un coup de pied aerien du joueur
            
            self.rect = Rect(x, y, 8, 8)
            # le rectangle d'occupation du sprite attack
            self.hitbox = Rect(x+8, y+16, 1, 1)
            # la hitbox du fouet qui va gerer les collisions avec les ennemis
            
            self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
            # image representant le fouet a tout moment, d'abord un carré transparent de 8x8
            self.image.convert()
    
        def update(self,
                   onGround,
                   crouching,
                   whipping,
                   sliding,
                   slidekicking,
                   facingRight,
                   elapsed,
                   playerxcoord, playerycoord,
                   richtersheet,
                   enemies):
            
            if not (whipping or sliding):    
                self.idle(playerxcoord, playerycoord, richtersheet)
                
            if whipping:
                self.whipattack(crouching, facingRight, elapsed, playerxcoord, playerycoord)
                
            if sliding:
                self.slide(richtersheet, facingRight, elapsed, playerxcoord, playerycoord)
                
            if slidekicking:
                self.slidekick(richtersheet, facingRight, elapsed, playerxcoord, playerycoord)
            
            if isinstance(self.image, PygAnimation):
                self.image = self.image.getCurrentFrame()
            # si l'image attack est un objet animation, le transformer en objet surface
                
            if not facingRight:
                self.image = transform.flip(self.image, True, False)
            # si le joueur regarde vers la gauche, retourner horizontalement le sprite
            
            
            self.xcoord = self.rect.topleft[0]
            self.ycoord = self.rect.topleft[1]
            
            self.collide(enemies)
            # faire les collisions
        
        def collide(self, enemies):
        # fonction pour verifier le collisions des attaques joueur aux ennemis
            for n in enemies:  
                if self.hitbox.colliderect(n.rect):
                    if isinstance(n, MedusaHead):
                        n.kill()
                
        def idle(self, playerxcoord, playerycoord, richtersheet):
        # fonction pour cacher les attaques lorsqu'elles ne se sont pas en cours
            self.rect = Rect(playerxcoord, playerycoord, 8, 8)
            self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
            self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
                
        def whipattack(self, crouching, facingRight, elapsed, playerxcoord, playerycoord):
            self.image = self.animWhipAttack
            self.animWhipAttack.play()
            if crouching:
                if facingRight:
                    if elapsed <= 0.1:
                        self.rect = Rect(playerxcoord-16, playerycoord+8, 16, 24)
                    elif elapsed <= 0.15:
                        self.rect = Rect(playerxcoord-24, playerycoord+8, 24, 16)
                    elif elapsed <= 0.2:
                        self.rect = Rect(playerxcoord+16, playerycoord+8, 40, 16)
                    elif elapsed <= 0.4:
                        self.rect = Rect(playerxcoord+16, playerycoord+8, 48, 16)
                    elif elapsed <= 0.6:
                        self.rect = Rect(playerxcoord+16, playerycoord+8, 16, 16)
                    else:
                        self.animWhipAttack.stop()
                        self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                        self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                        self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
                if not facingRight:
                    if elapsed <= 0.1:
                        self.rect = Rect(playerxcoord+16, playerycoord+8, 16, 24)
                    elif elapsed <= 0.15:
                        self.rect = Rect(playerxcoord+16, playerycoord+8, 24, 16)
                    elif elapsed <= 0.2:
                        self.rect = Rect(playerxcoord-40, playerycoord+8, 40, 16)
                    elif elapsed <= 0.4:
                        self.rect = Rect(playerxcoord-48, playerycoord+8, 48, 16)
                    elif elapsed <= 0.6:
                        self.rect = Rect(playerxcoord-16, playerycoord+8, 16, 16)
                    else:
                        self.animWhipAttack.stop()
                        self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                        self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                        self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
            if not crouching:
                if facingRight:
                    if elapsed <= 0.1:
                        self.rect = Rect(playerxcoord-16, playerycoord, 16, 24)
                        self.hitbox = Rect(playerxcoord-16, playerycoord+8, 16, 16)
                    elif elapsed <= 0.15:
                        self.rect = Rect(playerxcoord-24, playerycoord, 24, 16)
                        self.hitbox = Rect(playerxcoord-24, playerycoord, 24, 16)
                    elif elapsed <= 0.2:
                        self.rect = Rect(playerxcoord+16, playerycoord, 40, 16)
                        self.hitbox = Rect(playerxcoord+16, playerycoord, 32, 16)
                    elif elapsed <= 0.4:
                        self.rect = Rect(playerxcoord+16, playerycoord, 48, 16)
                        self.hitbox = Rect(playerxcoord+16, playerycoord+8, 48, 8)
                    elif elapsed <= 0.6:
                        self.rect = Rect(playerxcoord+16, playerycoord, 16, 16)
                        self.hitbox = Rect(playerxcoord+16, playerycoord+8, 16, 8)
                    else:
                        self.animWhipAttack.stop()
                        self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                        self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                        self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
                if not facingRight:
                    if elapsed <= 0.1:
                        self.rect = Rect(playerxcoord+16, playerycoord, 16, 24)
                        self.hitbox = Rect(playerxcoord+16, playerycoord+8, 16, 16)
                    elif elapsed <= 0.15:
                        self.rect = Rect(playerxcoord+16, playerycoord, 24, 16)
                        self.hitbox = Rect(playerxcoord+16, playerycoord, 24, 16)
                    elif elapsed <= 0.2:
                        self.rect = Rect(playerxcoord-40, playerycoord, 40, 16)
                        self.hitbox = Rect(playerxcoord-40, playerycoord, 32, 16)
                    elif elapsed <= 0.4:
                        self.rect = Rect(playerxcoord-48, playerycoord, 48, 16)
                        self.hitbox = Rect(playerxcoord-48, playerycoord+8, 48, 8)
                    elif elapsed <= 0.6:
                        self.rect = Rect(playerxcoord-16, playerycoord, 16, 16)
                        self.hitbox = Rect(playerxcoord-16, playerycoord+8, 16, 8)
                    else:
                        self.animWhipAttack.stop()
                        self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                        self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                        self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
                        
        def slide(self, richtersheet, facingRight, elapsed, playerxcoord, playerycoord):
            self.image = self.animSlide
            self.animSlide.play()
            if facingRight:
                if elapsed <= 0.05:
                    self.rect = Rect(playerxcoord+16, playerycoord, 8, 32)
                    self.hitbox = Rect(playerxcoord+16, playerycoord+16, 8, 16)
                elif elapsed <= 0.1:
                    self.rect = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord+16, playerycoord+24, 16, 8)
                elif elapsed <= 0.4:
                    self.rect = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                elif elapsed <= 0.5:
                    self.rect = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord+16, playerycoord+24, 16, 8)
                else:
                    self.animSlide.stop()
                    self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                    self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                    self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
            if not facingRight:
                if elapsed <= 0.05:
                    self.rect = Rect(playerxcoord-8, playerycoord, 8, 32)
                    self.hitbox = Rect(playerxcoord-8, playerycoord+16, 8, 16)
                elif elapsed <= 0.1:
                    self.rect = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord-16, playerycoord+24, 16, 8)
                elif elapsed <= 0.4:
                    self.rect = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                elif elapsed <= 0.5:
                    self.rect = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord-16, playerycoord+24, 16, 8)
                else:
                    self.animSlide.stop()
                    self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                    self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                    self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
                    
        def slidekick(self, richtersheet, facingRight, elapsed, playerxcoord, playerycoord):
            self.image = self.animSlidekick
            self.animSlidekick.play()
            if facingRight:
                if elapsed <= 0.7:
                    self.rect = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord+16, playerycoord+16, 16, 16)
                else:
                    self.animSlidekick.stop()
                    self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                    self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                    self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))
            if not facingRight:
                if elapsed <= 0.7:
                    self.rect = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                    self.hitbox = Rect(playerxcoord-16, playerycoord+16, 16, 16)
                else:
                    self.animSlidekick.stop()
                    self.rect = Rect(playerxcoord, playerycoord, 8, 8)
                    self.hitbox = Rect(playerxcoord+8, playerycoord+16, 1, 1)
                    self.image = richtersheet.image_at((2,70,8,8), colorkey=(185,209,217))